package com.akula.gm

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private val installedAppsList = mutableListOf<AppModel>()
    private var selectedPackageName: String? = null
    private lateinit var appAdapter: ArrayAdapter<String>
    private val appNames = mutableListOf<String>()

    data class AppModel(val name: String, val packageName: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        checkOverlayPermission()

        val creditBtn = findViewById<ImageView>(R.id.creditBtn)
        val creditModal = findViewById<View>(R.id.creditModal)
        val closeCreditBtn = findViewById<Button>(R.id.closeCreditBtn)
        val shizukuConnectBtn = findViewById<Button>(R.id.shizukuConnectBtn)
        val shizukuStatusTv = findViewById<TextView>(R.id.shizukuStatusTv)
        val topToast = findViewById<View>(R.id.topToast)

        val gameListView = findViewById<ListView>(R.id.gameListView)
        val addGameBtn = findViewById<Button>(R.id.addGameBtn)
        val pkgInfoTv = findViewById<TextView>(R.id.pkgInfoTv)
        val launchItBtn = findViewById<Button>(R.id.launchItBtn)

        appAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_single_choice, appNames)
        gameListView.adapter = appAdapter
        gameListView.choiceMode = ListView.CHOICE_MODE_SINGLE

        if (ShizukuBridge.isAvailable()) {
            shizukuStatusTv.text = "Shizuku Status: Connected"
            topToast.visibility = View.GONE
        } else {
            shizukuStatusTv.text = "Shizuku Status: Not Yet"
            topToast.visibility = View.VISIBLE
        }

        shizukuConnectBtn.setOnClickListener {
            ShizukuBridge.requestPermission(this)
        }

        creditBtn.setOnClickListener { creditModal.visibility = View.VISIBLE }
        closeCreditBtn.setOnClickListener { creditModal.visibility = View.GONE }

        addGameBtn.setOnClickListener {
            openAppPicker()
        }

        gameListView.setOnItemClickListener { _, _, position, _ ->
            val selected = installedAppsList[position]
            selectedPackageName = selected.packageName
            pkgInfoTv.text = "Package: ${selected.packageName}"
        }

        launchItBtn.setOnClickListener {
            selectedPackageName?.let { pkg ->
                val overlayIntent = Intent(this, FloatingWindowService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(overlayIntent)
                } else {
                    startService(overlayIntent)
                }

                val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    startActivity(launchIntent)
                } else {
                    Toast.makeText(this, "Unable to launch $pkg", Toast.LENGTH_SHORT).show()
                }
            } ?: run {
                Toast.makeText(this, "Please select or add a game first!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun openAppPicker() {
        val pm = packageManager
        val packages = pm.getInstalledApplications(0)
        installedAppsList.clear()
        appNames.clear()

        for (app in packages) {
            if (pm.getLaunchIntentForPackage(app.packageName) != null) {
                val label = pm.getApplicationLabel(app).toString()
                installedAppsList.add(AppModel(label, app.packageName))
                appNames.add(label)
            }
        }
        appAdapter.notifyDataSetChanged()
    }

    private fun checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }
}
