package com.akula.gm

import android.content.Context
import android.widget.Toast

object ShizukuBridge {
    fun isAvailable(): Boolean {
        return false // Stub implementation for Gradle build compliance
    }

    fun requestPermission(context: Context) {
        Toast.makeText(context, "Shizuku permission check initialized", Toast.LENGTH_SHORT).show()
    }
}
