package com.akula.gm

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingWindowService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingBubbleView: View
    private lateinit var wfPanelView: View

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundServiceNotification()

        setupFloatingBubble()
        setupWFPanel()
    }

    private fun setupFloatingBubble() {
        floatingBubbleView = LayoutInflater.from(this).inflate(R.layout.bubble_layout, null)

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        layoutParams.gravity = Gravity.TOP or Gravity.START
        layoutParams.x = 100
        layoutParams.y = 100

        windowManager.addView(floatingBubbleView, layoutParams)

        floatingBubbleView.setOnTouchListener(object : View.OnTouchListener {
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        layoutParams.x = initialX + (event.rawX - initialTouchX).toInt()
                        layoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(floatingBubbleView, layoutParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val diffX = Math.abs(event.rawX - initialTouchX)
                        val diffY = Math.abs(event.rawY - initialTouchY)
                        if (diffX < 10 && diffY < 10) {
                            toggleWFPanel(true)
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun setupWFPanel() {
        wfPanelView = LayoutInflater.from(this).inflate(R.layout.window_function_overlay, null)

        val wfLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        wfLayoutParams.gravity = Gravity.CENTER

        wfPanelView.visibility = View.GONE
        windowManager.addView(wfPanelView, wfLayoutParams)

        val closeIcon = wfPanelView.findViewById<ImageView>(R.id.wfCloseIcon)
        val closeBtn = wfPanelView.findViewById<Button>(R.id.wfCloseBtn)
        val confirmDialog = wfPanelView.findViewById<View>(R.id.confirmDialog)
        val btnNo = wfPanelView.findViewById<Button>(R.id.btnNo)
        val btnYes = wfPanelView.findViewById<Button>(R.id.btnYes)

        val ramTv = wfPanelView.findViewById<TextView>(R.id.ramTv)
        val fpsTv = wfPanelView.findViewById<TextView>(R.id.fpsTv)
        val tempTv = wfPanelView.findViewById<TextView>(R.id.tempTv)

        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val availMb = mi.availMem / (1024 * 1024)
        val totalMb = mi.totalMem / (1024 * 1024)
        ramTv.text = "$availMb/$totalMb MB free"

        val currentFps = 60
        fpsTv.text = "$currentFps FPS"
        when {
            currentFps < 15 -> fpsTv.setTextColor(Color.RED)
            currentFps <= 35 -> fpsTv.setTextColor(Color.YELLOW)
            else -> fpsTv.setTextColor(Color.GREEN)
        }

        val tempC = 37.5
        tempTv.text = "$tempC °C"
        if (tempC < 40) {
            tempTv.setTextColor(Color.parseColor("#00E5FF"))
        } else {
            tempTv.setTextColor(Color.parseColor("#FF9100"))
        }

        closeIcon.setOnClickListener { toggleWFPanel(false) }
        closeBtn.setOnClickListener { confirmDialog.visibility = View.VISIBLE }

        btnNo.setOnClickListener {
            confirmDialog.visibility = View.GONE
            toggleWFPanel(false)
        }

        btnYes.setOnClickListener {
            stopSelf()
            System.exit(0)
        }
    }

    private fun toggleWFPanel(show: Boolean) {
        if (show) {
            wfPanelView.visibility = View.VISIBLE
            floatingBubbleView.visibility = View.GONE
        } else {
            wfPanelView.visibility = View.GONE
            floatingBubbleView.visibility = View.VISIBLE
        }
    }

    private fun startForegroundServiceNotification() {
        val channelId = "akula_gm_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "AKULA GM Service",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("AKULA GM Active")
            .setContentText("Game Space Overlay Running...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        startForeground(1001, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::floatingBubbleView.isInitialized) windowManager.removeView(floatingBubbleView)
        if (::wfPanelView.isInitialized) windowManager.removeView(wfPanelView)
    }
}
