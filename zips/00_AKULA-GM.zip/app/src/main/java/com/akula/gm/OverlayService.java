package com.akula.gm;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;

/** The REAL floating circle + panel that sit on top of the game. */
public class OverlayService extends Service implements PanelView.Host {
    private static final String ACTION_STOP = "com.akula.gm.STOP";

    private WindowManager wm;
    private LogoView bubble;
    private PanelView panel;
    private WindowManager.LayoutParams bp;
    private int size;
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        size = Ui.dp(this, 46);
        goForeground();
    }

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("akula", "AKULA GM overlay", NotificationManager.IMPORTANCE_MIN));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Icon icon = Icon.createWithResource(this, R.drawable.ic_stat);
        Notification n = new Notification.Builder(this, "akula")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("AKULA GM is running")
                .setContentText("Tap the floating circle to open the panel")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(icon, "Stop", stopPi).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            quit();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && intent.hasExtra("pkg")) {
            Tools.setTarget(this, intent.getStringExtra("pkg"), intent.getStringExtra("name"));
            Tools.gameOpt = false;
            Tools.bg = 0;
        }
        addBubble();
        return START_NOT_STICKY;
    }

    private int[] screen() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    // ---------------- the circle ----------------
    private void addBubble() {
        if (bubble != null) return;
        bubble = new LogoView(this);
        bubble.setAlpha(0.85f);
        int[] s = screen();
        bp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        bp.gravity = Gravity.TOP | Gravity.START;
        bp.x = Tools.sp(this).getInt("bx", s[0] - size - Ui.dp(this, 6));
        bp.y = Tools.sp(this).getInt("by", s[1] / 3);
        clampBubble();
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();

        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = bp.x;
                        startY = bp.y;
                        moved = false;
                        v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (!moved && Math.hypot(dx, dy) > slop) moved = true;
                        if (moved) {
                            bp.x = startX + (int) dx;
                            bp.y = startY + (int) dy;
                            clampBubble();
                            try {
                                wm.updateViewLayout(bubble, bp);
                            } catch (Throwable ignored) {
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                        if (e.getActionMasked() == MotionEvent.ACTION_UP && !moved) {
                            expand();
                        } else if (moved) {
                            snapToEdge();
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
        try {
            wm.addView(bubble, bp);
        } catch (Throwable t) {
            bubble = null;
            stopSelf();
        }
    }

    private void clampBubble() {
        if (bp == null) return;
        int[] s = screen();
        bp.x = Math.max(0, Math.min(bp.x, s[0] - size));
        bp.y = Math.max(0, Math.min(bp.y, s[1] - size));
    }

    private void snapToEdge() {
        int[] s = screen();
        final int from = bp.x;
        final int to = (bp.x + size / 2 < s[0] / 2) ? 0 : s[0] - size;
        ValueAnimator va = ValueAnimator.ofInt(from, to);
        va.setDuration(180);
        va.addUpdateListener(a -> {
            if (bubble == null || !bubble.isAttachedToWindow()) return;
            bp.x = (Integer) a.getAnimatedValue();
            try {
                wm.updateViewLayout(bubble, bp);
            } catch (Throwable ignored) {
            }
        });
        va.start();
        Tools.sp(this).edit().putInt("bx", to).putInt("by", bp.y).apply();
    }

    // ---------------- the panel (wf) ----------------
    private WindowManager.LayoutParams panelParams() {
        int[] s = screen();
        boolean land = s[0] > s[1];
        int w = land ? (int) (s[0] * 0.60f) : (int) (s[0] * 0.94f);
        int hh = land ? (int) (s[1] * 0.90f) : (int) (s[1] * 0.72f);
        w = Math.max(w, Math.min(s[0], Ui.dp(this, 330)));
        hh = Math.max(hh, Math.min(s[1], Ui.dp(this, 220)));
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, hh,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.CENTER;
        return p;
    }

    private void expand() {
        if (panel != null || bubble == null) return;
        PanelView p = new PanelView(this, this);
        try {
            wm.addView(p, panelParams());
        } catch (Throwable t) {
            return;
        }
        panel = p;
        bubble.setVisibility(View.GONE);
        p.setAlpha(0f);
        p.setScaleX(0.85f);
        p.setScaleY(0.85f);
        p.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start();
        p.start();
    }

    @Override
    public void collapse() {
        if (panel == null) return;
        final PanelView p = panel;
        panel = null;
        p.stop();
        p.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f).setDuration(150).withEndAction(() -> {
            try {
                wm.removeView(p);
            } catch (Throwable ignored) {
            }
        }).start();
        if (bubble != null) {
            bubble.setVisibility(View.VISIBLE);
            bubble.setScaleX(0.6f);
            bubble.setScaleY(0.6f);
            bubble.animate().scaleX(1f).scaleY(1f).setDuration(180).start();
        }
    }

    /** "Yes" on the close question: close the panel, the circle, and AKULA GM. The game keeps running. */
    @Override
    public void quit() {
        h.removeCallbacksAndMessages(null);
        Tools.setHeat(this, false);
        if (panel != null) {
            panel.stop();
            try {
                wm.removeView(panel);
            } catch (Throwable ignored) {
            }
            panel = null;
        }
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Throwable ignored) {
            }
            bubble = null;
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
        // The game is a different app (different process), so it is not touched.
        new Handler(Looper.getMainLooper()).postDelayed(() -> Process.killProcess(Process.myPid()), 250);
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        h.postDelayed(() -> {
            if (panel != null) {
                try {
                    wm.updateViewLayout(panel, panelParams());
                } catch (Throwable ignored) {
                }
            }
            if (bubble != null && bp != null) {
                clampBubble();
                try {
                    wm.updateViewLayout(bubble, bp);
                } catch (Throwable ignored) {
                }
            }
        }, 150);
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (panel != null) {
            try {
                wm.removeView(panel);
            } catch (Throwable ignored) {
            }
            panel = null;
        }
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Throwable ignored) {
            }
            bubble = null;
        }
        super.onDestroy();
    }
}
