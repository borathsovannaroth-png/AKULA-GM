package com.akula.gm;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.provider.Settings;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** All the optimize actions. Every function here must run on a background thread (use Tools.IO). */
final class Tools {
    private Tools() {}

    static final String SELF = "com.akula.gm";
    static final ExecutorService IO = Executors.newCachedThreadPool();
    static final Handler MAIN = new Handler(Looper.getMainLooper());

    static volatile boolean gameOpt, selfOpt, heat, perf;
    /** 0 = not yet, 1 = yes, 2 = still have some */
    static volatile int bg = 0;

    // ---------- small stored values ----------
    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("akula", Context.MODE_PRIVATE);
    }

    static String target(Context c) {
        return sp(c).getString("target", null);
    }

    static void setTarget(Context c, String pkg, String name) {
        sp(c).edit().putString("target", pkg).putString("targetName", name).apply();
    }

    // ---------- real numbers ----------
    static long availMb(Context c) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        return mi.availMem / 1048576L;
    }

    static long totalMb(Context c) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        return mi.totalMem / 1048576L;
    }

    /** Battery temperature in Celsius, or -1 if unknown. */
    static float tempC(Context c) {
        try {
            Intent i = c.getApplicationContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i == null) return -1;
            int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            if (t == Integer.MIN_VALUE) return -1;
            return t / 10f;
        } catch (Throwable e) {
            return -1;
        }
    }

    static boolean powerSaveOn(Context c) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isPowerSaveMode();
    }

    private static long freeBytes() {
        try {
            return new StatFs(Environment.getDataDirectory().getPath()).getAvailableBytes();
        } catch (Throwable e) {
            return 0;
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }

    // ---------- app lists ----------
    private static Set<String> protectedPkgs(Context c, String game) {
        Set<String> s = new HashSet<>();
        s.add(SELF);
        s.add(Sh.PKG);
        if (game != null) s.add(game);
        try {
            ResolveInfo home = c.getPackageManager().resolveActivity(
                    new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0);
            if (home != null) s.add(home.activityInfo.packageName);
            String ime = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
            if (ime != null && ime.contains("/")) s.add(ime.substring(0, ime.indexOf('/')));
        } catch (Throwable ignored) {
        }
        return s;
    }

    /** Only apps the user installed themselves (never system apps). */
    private static List<String> userApps(Context c, Set<String> protect) {
        Set<String> out = new LinkedHashSet<>();
        try {
            List<ResolveInfo> l = c.getPackageManager().queryIntentActivities(
                    new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
            for (ResolveInfo r : l) {
                ApplicationInfo ai = r.activityInfo.applicationInfo;
                if ((ai.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0) continue;
                String p = ai.packageName;
                if (protect.contains(p) || !Sh.safePkg(p)) continue;
                out.add(p);
            }
        } catch (Throwable ignored) {
        }
        return new ArrayList<>(out);
    }

    // ---------- actions ----------
    static String clearRam(Context c, String game) {
        long before = availMb(c);
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        for (String p : userApps(c, protectedPkgs(c, game))) {
            try {
                am.killBackgroundProcesses(p);
            } catch (Throwable ignored) {
            }
        }
        // Kills only cached (not-in-use) processes. Safe.
        if (Sh.ready()) Sh.run("am kill-all", 8000);
        sleep(800);
        long after = availMb(c);
        long d = after - before;
        return d > 0 ? "RAM cleared: freed about " + d + " MB (" + after + " MB free now)"
                : "RAM already clean (" + after + " MB free)";
    }

    static String optimizeGame(Context c, String game) {
        if (!Sh.safePkg(game)) return "Launch a game from AKULA GM first";
        String ram = clearRam(c, game);
        if (!Sh.ready()) {
            gameOpt = false;
            return "Only the basic boost was done. Connect Shizuku for full game optimize. " + ram;
        }
        Sh.run("am set-standby-bucket " + game + " active; cmd deviceidle whitelist +" + game, 8000);
        Sh.run("cmd package compile -m speed-profile " + game, 90000);
        gameOpt = true;
        return "Game optimized: high priority, battery limit lifted, code compiled. " + ram;
    }

    static String optimizeSelf(Context c) {
        deleteContents(c.getCacheDir());
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        if (Sh.ready()) {
            Sh.run("cmd deviceidle whitelist +" + SELF + "; am set-standby-bucket " + SELF
                    + " active; cmd appops set " + SELF + " RUN_ANY_IN_BACKGROUND allow", 8000);
            selfOpt = true;
            return "AKULA GM optimized: Android will not put it to sleep";
        }
        if (pm != null && pm.isIgnoringBatteryOptimizations(SELF)) {
            selfOpt = true;
            return "AKULA GM is already allowed to run in the background";
        }
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + SELF));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable ignored) {
        }
        return "Tap Allow in the popup, then press Activate again";
    }

    static String clearCache(Context c, String game) {
        long before = freeBytes();
        deleteContents(c.getCacheDir());
        deleteContents(c.getExternalCacheDir());
        boolean deep = Sh.ready();
        if (deep) {
            if (Sh.safePkg(game)) Sh.run("rm -rf /sdcard/Android/data/" + game + "/cache/*", 15000);
            Sh.run("pm trim-caches 999999999999", 30000);
        }
        sleep(400);
        long freed = (freeBytes() - before) / 1048576L;
        String base = freed > 1 ? "Cache cleared: freed about " + freed + " MB" : "Cache cleaned (nothing big to free)";
        return deep ? base : base + " (only AKULA GM cache; Shizuku cleans the game too)";
    }

    static String clearBackground(Context c, String game) {
        List<String> apps = userApps(c, protectedPkgs(c, game));
        if (Sh.ready()) {
            StringBuilder sb = new StringBuilder();
            for (String p : apps) sb.append("am force-stop ").append(p).append(';');
            if (sb.length() > 0) Sh.run(sb.toString(), 25000);
            int left = runningCount(apps);
            bg = left == 0 ? 1 : 2;
            return left == 0 ? "Stopped " + apps.size() + " background apps"
                    : "Stopped " + apps.size() + " apps, " + left + " came back or are still running";
        }
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        for (String p : apps) {
            try {
                am.killBackgroundProcesses(p);
            } catch (Throwable ignored) {
            }
        }
        bg = 1;
        return "Basic clean done. Connect Shizuku for a deeper clean (and a real check)";
    }

    private static int runningCount(List<String> apps) {
        String ps = Sh.run("ps -A -o NAME", 6000);
        if (ps == null) return 0;
        Set<String> running = new HashSet<>();
        for (String line : ps.split("\n")) {
            String l = line.trim();
            int i = l.indexOf(':');
            if (i > 0) l = l.substring(0, i);
            running.add(l);
        }
        int n = 0;
        for (String p : apps) if (running.contains(p)) n++;
        return n;
    }

    static String setPowerSave(Context c, boolean on) {
        if (!Sh.ready()) {
            try {
                Intent i = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
            } catch (Throwable ignored) {
            }
            return "Needs Shizuku. Opened Battery Saver settings so you can switch it by hand";
        }
        Sh.run("settings put global low_power " + (on ? 1 : 0)
                + (on ? "" : "; settings put global low_power_sticky 0"), 6000);
        sleep(500);
        return on ? "Power save ON" : "Power save OFF";
    }

    static String setPerf(Context c, String game, boolean on) {
        if (!Sh.ready()) {
            perf = false;
            return "Gaming full performance needs Shizuku";
        }
        StringBuilder cmd = new StringBuilder();
        if (on) {
            cmd.append("settings put global low_power 0; cmd power set-fixed-performance-mode-enabled true;");
            if (Sh.safePkg(game)) {
                cmd.append("cmd game mode performance ").append(game).append(" 2>/dev/null;");
                cmd.append("cmd game set --mode performance ").append(game).append(" 2>/dev/null;");
            }
        } else {
            cmd.append("cmd power set-fixed-performance-mode-enabled false;");
            if (Sh.safePkg(game)) {
                cmd.append("cmd game mode standard ").append(game).append(" 2>/dev/null;");
                cmd.append("cmd game reset ").append(game).append(" 2>/dev/null;");
            }
        }
        Sh.run(cmd.toString(), 10000);
        perf = on;
        return on ? "Full performance ON (best effort; some phones ignore parts of it)" : "Full performance OFF";
    }

    static void setHeat(Context c, boolean on) {
        appCtx = c.getApplicationContext();
        heat = on;
        MAIN.removeCallbacks(HEAT);
        if (on) MAIN.post(HEAT);
    }

    private static Context appCtx;
    private static final Runnable HEAT = new Runnable() {
        @Override
        public void run() {
            if (!heat || appCtx == null) return;
            final Context c = appCtx;
            IO.execute(() -> clearRam(c, target(c)));
            MAIN.postDelayed(this, 60000);
        }
    };

    static int touchLevel(Context c) {
        try {
            int lp = Settings.Secure.getInt(c.getContentResolver(), "long_press_timeout", 400);
            return Math.max(0, Math.min(100, Math.round((800 - lp) / 6f)));
        } catch (Throwable e) {
            return 67;
        }
    }

    static String touchText(int level) {
        return "Hold delay " + (800 - 6 * level) + " ms";
    }

    static String setTouch(Context c, int level) {
        level = Math.max(0, Math.min(100, level));
        int lp = 800 - 6 * level;
        int mp = 400 - 2 * level;
        if (!Sh.ready()) return "Fix touch needs Shizuku";
        Sh.run("settings put secure long_press_timeout " + lp + "; settings put secure multi_press_timeout " + mp, 6000);
        return "Touch reaction set: hold delay " + lp + " ms, double tap " + mp + " ms";
    }

    private static void deleteContents(File dir) {
        if (dir == null) return;
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (f.isDirectory()) deleteContents(f);
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
    }
}
