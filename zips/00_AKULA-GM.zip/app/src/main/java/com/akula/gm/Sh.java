package com.akula.gm;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

/** Everything about Shizuku in one place. */
final class Sh {
    private Sh() {}

    static final String PKG = "moe.shizuku.privileged.api";
    static final int REQ = 4217;

    static boolean installed(Context c) {
        try {
            c.getPackageManager().getPackageInfo(PKG, 0);
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    static boolean binder() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean granted() {
        try {
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean ready() {
        return binder() && granted();
    }

    /** 0 = not installed, 1 = installed but not running, 2 = running but not allowed yet, 3 = connected */
    static int state(Context c) {
        if (ready()) return 3;
        if (binder()) return 2;
        if (installed(c)) return 1;
        return 0;
    }

    static String hint(int s) {
        switch (s) {
            case 3: return "Connected successfully";
            case 2: return "Not yet (tap Connect now and allow)";
            case 1: return "Not yet (open Shizuku and start it)";
            default: return "Not yet (Shizuku is not installed)";
        }
    }

    static void requestPermission() {
        try {
            Shizuku.requestPermission(REQ);
        } catch (Throwable ignored) {
        }
    }

    static boolean open(Context c) {
        try {
            Intent i = c.getPackageManager().getLaunchIntentForPackage(PKG);
            if (i == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    static void openDownload(Context c) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable ignored) {
        }
    }

    /** Connect now / Refresh / Go to Shizuku all use this. Returns a short message for the user. */
    static String connect(Context c) {
        int s = state(c);
        if (s == 3) return "Shizuku is already connected";
        if (s == 2) {
            requestPermission();
            return "Tap Allow in the Shizuku popup";
        }
        if (s == 1) {
            open(c);
            return "Start Shizuku, then come back here";
        }
        openDownload(c);
        return "Install Shizuku first, then come back";
    }

    static boolean safePkg(String p) {
        return p != null && p.length() < 200 && p.matches("[A-Za-z0-9_.]+");
    }

    /** Runs a shell command with Shizuku power. Never call on the main thread. Returns null if Shizuku is not ready. */
    static String run(String cmd, long timeoutMs) {
        if (!ready()) return null;
        Process p = null;
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            p = (Process) m.invoke(null, new String[]{"sh", "-c", "(" + cmd + ") 2>&1"}, null, null);
            final Process fp = p;
            final StringBuilder sb = new StringBuilder();
            Thread t = new Thread(() -> {
                try (BufferedReader r = new BufferedReader(new InputStreamReader(fp.getInputStream()))) {
                    String l;
                    while ((l = r.readLine()) != null) {
                        synchronized (sb) {
                            sb.append(l).append('\n');
                        }
                    }
                } catch (Throwable ignored) {
                }
            });
            t.start();
            t.join(timeoutMs);
            synchronized (sb) {
                return sb.toString();
            }
        } catch (Throwable e) {
            return null;
        } finally {
            if (p != null) {
                try {
                    p.destroy();
                } catch (Throwable ignored) {
                }
            }
        }
    }
}
