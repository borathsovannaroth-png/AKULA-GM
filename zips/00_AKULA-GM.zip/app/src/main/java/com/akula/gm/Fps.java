package com.akula.gm;

/**
 * Reads the REAL frame rate of the game from SurfaceFlinger (needs Shizuku).
 * Returns -1 when it cannot be measured, so the app never shows a fake number.
 */
final class Fps {
    private String pkg;
    private String layer;

    private static String pick(String list, String pkg) {
        if (list == null) return null;
        String best = null;
        int bestScore = -100;
        for (String raw : list.split("\n")) {
            String l = raw.trim();
            if (l.isEmpty() || !l.contains(pkg)) continue;
            int s = 1;
            if (l.startsWith("SurfaceView")) s += 4;
            if (l.contains("BLAST")) s += 2;
            if (l.contains("Bounds") || l.contains("Background") || l.contains("Splash")) s -= 3;
            if (s > bestScore) {
                bestScore = s;
                best = l;
            }
        }
        return best;
    }

    int sample(String target) {
        if (!Sh.ready() || !Sh.safePkg(target)) return -1;
        if (!target.equals(pkg)) {
            pkg = target;
            layer = null;
        }
        if (layer == null) {
            layer = pick(Sh.run("dumpsys SurfaceFlinger --list", 5000), target);
            if (layer == null) return -1;
        }
        String out = Sh.run("dumpsys SurfaceFlinger --latency '" + layer.replace("'", "") + "'", 5000);
        if (out == null) {
            layer = null;
            return -1;
        }
        String[] lines = out.split("\n");
        long[] ts = new long[lines.length];
        int n = 0;
        for (int i = 1; i < lines.length; i++) {
            String[] p = lines[i].trim().split("\\s+");
            if (p.length < 3) continue;
            try {
                long v = Long.parseLong(p[1]);
                if (v > 0 && v < Long.MAX_VALUE / 2) ts[n++] = v;
            } catch (NumberFormatException ignored) {
            }
        }
        if (n < 2) {
            layer = null;
            return -1;
        }
        long max = 0;
        for (int i = 0; i < n; i++) max = Math.max(max, ts[i]);
        // Game not drawing anything right now
        if (System.nanoTime() - max > 2_500_000_000L) return 0;
        long min = max;
        int cnt = 0;
        for (int i = 0; i < n; i++) {
            if (ts[i] > max - 1_000_000_000L) {
                cnt++;
                if (ts[i] < min) min = ts[i];
            }
        }
        if (cnt < 2 || max == min) return cnt;
        return (int) Math.min(240, Math.round((cnt - 1) * 1e9 / (max - min)));
    }
}
