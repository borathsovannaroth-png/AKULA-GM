package com.akula.gm;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.widget.TextView;

/** Small helpers for colors and the "frost glass" look. */
final class Ui {
    private Ui() {}

    static final int BG1 = 0xFF030814;
    static final int BG2 = 0xFF0B1F44;
    static final int TXT = 0xFFEAF1FF;
    static final int MUTED = 0xFF8FA6CF;
    static final int BLUE = 0xFF3B82F6;
    static final int SKY = 0xFF38BDF8;
    static final int ORANGE = 0xFFF97316;
    static final int RED = 0xFFEF4444;
    static final int YELLOW = 0xFFFACC15;
    static final int GREEN = 0xFF22C55E;
    static final int NAVY = 0xFF1E3A8A;
    static final int PURPLE = 0xFF8B5CF6;
    static final int GRAY = 0xFF64748B;

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | ((a & 0xFF) << 24);
    }

    static int lighten(int c, float f) {
        int r = Color.red(c), g = Color.green(c), b = Color.blue(c);
        r = Math.round(r + (255 - r) * f);
        g = Math.round(g + (255 - g) * f);
        b = Math.round(b + (255 - b) * f);
        return Color.rgb(r, g, b);
    }

    /** Frost glass: see-through tint, soft top light, thin bright border. */
    static GradientDrawable glass(Context c, int tint, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{alpha(tint, 0x66), alpha(tint, 0x26)});
        d.setCornerRadius(dp(c, radiusDp));
        d.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        return d;
    }

    static Drawable ripple(Context c, Drawable content, float radiusDp) {
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(Color.WHITE);
        mask.setCornerRadius(dp(c, radiusDp));
        return new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), content, mask);
    }

    static TextView label(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setIncludeFontPadding(false);
        return t;
    }

    static TextView pill(Context c, String s, int tint, int textColor, float sp) {
        TextView t = label(c, s, sp, textColor, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 12), dp(c, 7), dp(c, 12), dp(c, 7));
        t.setBackground(ripple(c, glass(c, tint, 14, alpha(tint, 0xCC), 1), 14));
        t.setClickable(true);
        return t;
    }
}
