package com.akula.gm;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** The "wf" (window function): the panel that opens when the floating circle is tapped. */
final class PanelView extends FrameLayout {

    interface Host {
        void collapse();

        void quit();
    }

    interface Job {
        String run() throws Exception;
    }

    /** A frost-glass stat box that smoothly fades between colors. */
    static final class Card extends LinearLayout {
        final GradientDrawable bg;
        final TextView t, v, s;
        int tint;
        ValueAnimator va;

        Card(Context c, String title, int tint) {
            super(c);
            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER);
            int p = Ui.dp(c, 8);
            setPadding(p, p, p, p);
            bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0, 0});
            bg.setCornerRadius(Ui.dp(c, 14));
            setBackground(bg);
            t = Ui.label(c, title, 9, Ui.MUTED, true);
            t.setLetterSpacing(0.1f);
            v = Ui.label(c, "--", 18, Ui.TXT, true);
            v.setMaxLines(1);
            v.setGravity(Gravity.CENTER);
            v.setAutoSizeTextTypeUniformWithConfiguration(10, 20, 1, TypedValue.COMPLEX_UNIT_SP);
            s = Ui.label(c, "", 9, Ui.MUTED, false);
            s.setGravity(Gravity.CENTER);
            addView(t);
            addView(v, new LinearLayout.LayoutParams(-1, -2));
            addView(s);
            this.tint = tint;
            apply(tint);
        }

        void apply(int c) {
            bg.setColors(new int[]{Ui.alpha(c, 0x77), Ui.alpha(c, 0x2A)});
            bg.setStroke(Math.max(1, Ui.dp(getContext(), 1)), Ui.alpha(c, 0xBB));
            v.setTextColor(Ui.lighten(c, 0.55f));
        }

        void setTint(int to) {
            if (to == tint) return;
            int from = tint;
            tint = to;
            if (va != null) va.cancel();
            va = ValueAnimator.ofObject(new ArgbEvaluator(), from, to);
            va.setDuration(700);
            va.addUpdateListener(a -> apply((Integer) a.getAnimatedValue()));
            va.start();
        }
    }

    private final Host host;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Fps fps = new Fps();
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private boolean running, syncing;
    private int tickN;

    private Card cRam, cFps, cTemp;
    private TextView note, stRam, stGame, stSelf, stBg, stPower, stHeat, stShz, seekVal;
    private Switch swPower, swPerf, swHeat;
    private SeekBar seek;
    private FrameLayout confirm;

    private int d(float v) {
        return Ui.dp(getContext(), v);
    }

    PanelView(Context c, Host host) {
        super(c);
        this.host = host;

        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xF0071329, 0xF00B2150});
        bg.setCornerRadius(d(22));
        bg.setStroke(d(1.5f), Ui.alpha(Ui.SKY, 0x77));
        setBackground(bg);
        setClipToOutline(true);

        LinearLayout content = new LinearLayout(c);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(d(14), d(10), d(14), d(12));
        addView(content, new FrameLayout.LayoutParams(-1, -1));

        // ----- header: AKULA GM (glow) ... X / CLOSE -----
        LinearLayout header = new LinearLayout(c);
        header.setOrientation(LinearLayout.HORIZONTAL);
        TextView title = Ui.label(c, "AKULA GM", 24, Ui.TXT, true);
        title.setShadowLayer(d(12), 0, 0, Ui.SKY);
        title.setLetterSpacing(0.06f);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout right = new LinearLayout(c);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.END);
        TextView x = Ui.label(c, "X", 15, Ui.TXT, true);
        x.setGravity(Gravity.CENTER);
        GradientDrawable xb = new GradientDrawable();
        xb.setShape(GradientDrawable.OVAL);
        xb.setColor(0x33FFFFFF);
        xb.setStroke(Math.max(1, d(1)), 0x88FFFFFF);
        x.setBackground(xb);
        x.setClickable(true);
        x.setOnClickListener(v -> host.collapse());
        right.addView(x, new LinearLayout.LayoutParams(d(34), d(34)));
        TextView close = Ui.pill(c, "CLOSE", Ui.RED, 0xFFFFB4B4, 10);
        close.setPadding(d(10), d(4), d(10), d(4));
        close.setOnClickListener(v -> confirm.setVisibility(VISIBLE));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
        clp.topMargin = d(8);
        right.addView(close, clp);
        header.addView(right, new LinearLayout.LayoutParams(-2, -2));
        content.addView(header, new LinearLayout.LayoutParams(-1, -2));

        // ----- scrollable body -----
        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(OVER_SCROLL_NEVER);
        LinearLayout.LayoutParams svp = new LinearLayout.LayoutParams(-1, 0, 1f);
        svp.topMargin = d(6);
        content.addView(sv, svp);
        LinearLayout list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list, new FrameLayout.LayoutParams(-1, -2));

        // 3 stat columns (little gap between them, each a different color)
        LinearLayout stats = new LinearLayout(c);
        cRam = new Card(c, "FREE RAM", Ui.BLUE);
        cFps = new Card(c, "FPS", Ui.GRAY);
        cTemp = new Card(c, "TEMP", Ui.SKY);
        stats.addView(cRam, statLp());
        stats.addView(cFps, statLp());
        stats.addView(cTemp, statLp());
        list.addView(stats, new LinearLayout.LayoutParams(-1, -2));

        note = Ui.label(c, "Ready", 10, Ui.lighten(Ui.SKY, 0.4f), false);
        note.setMaxLines(3);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = d(8);
        list.addView(note, np);

        list.addView(section("OPTIMIZE"));

        TextView rf1 = rf();
        rf1.setOnClickListener(v -> runJob(rf1, () -> Tools.optimizeGame(getContext(), Tools.target(getContext()))));
        addRow(list, "Optimize game", "Boost the game you launched", rf1);

        TextView ab1 = ab();
        ab1.setOnClickListener(v -> runJob(ab1, () -> Tools.optimizeSelf(getContext())));
        addRow(list, "Optimize AKULA GM", "Keep this app awake", ab1);

        TextView rf2 = rf();
        rf2.setOnClickListener(v -> runJob(rf2, () -> Tools.clearCache(getContext(), Tools.target(getContext()))));
        addRow(list, "Clear cache", "Free storage", rf2);

        TextView rf3 = rf();
        rf3.setOnClickListener(v -> runJob(rf3, () -> Tools.clearRam(getContext(), Tools.target(getContext()))));
        addRow(list, "Clear RAM", "Free memory now", rf3);

        swPower = sw();
        swPower.setOnCheckedChangeListener((b, on) -> {
            if (syncing) return;
            runJob(swPower, () -> Tools.setPowerSave(getContext(), on));
        });
        addRow(list, "Power save", "Battery saver on / off", swPower);

        swPerf = sw();
        swPerf.setOnCheckedChangeListener((b, on) -> {
            if (syncing) return;
            runJob(swPerf, () -> Tools.setPerf(getContext(), Tools.target(getContext()), on));
        });
        addRow(list, "Gaming full performance", "Max speed mode", swPerf);

        swHeat = sw();
        swHeat.setOnCheckedChangeListener((b, on) -> {
            if (syncing) return;
            Tools.setHeat(getContext(), on);
            note.setText(on ? "Heat reducer ON: cleans background apps every minute so they do not add heat"
                    : "Heat reducer OFF");
            update();
        });
        addRow(list, "Heat reducer", "Less background load = less heat", swHeat);

        TextView ab2 = ab();
        ab2.setOnClickListener(v -> runJob(ab2, () -> Tools.clearBackground(getContext(), Tools.target(getContext()))));
        addRow(list, "Clear background apps", "Except AKULA GM + Shizuku", ab2);

        // fix touch
        LinearLayout touch = new LinearLayout(c);
        touch.setOrientation(LinearLayout.VERTICAL);
        touch.setPadding(d(12), d(10), d(12), d(8));
        touch.setBackground(Ui.glass(c, Ui.NAVY, 14, 0x33FFFFFF, 1));
        touch.addView(Ui.label(c, "Fix touch", 13, Ui.TXT, true));
        touch.addView(Ui.label(c, "How fast the screen reacts to your touch", 10, Ui.MUTED, false));
        seek = new SeekBar(c);
        seek.setMax(100);
        seek.setProgress(Tools.touchLevel(c));
        seek.setProgressTintList(ColorStateList.valueOf(Ui.SKY));
        seek.setThumbTintList(ColorStateList.valueOf(Ui.SKY));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = d(4);
        touch.addView(seek, sp);
        LinearLayout labels = new LinearLayout(c);
        TextView minT = Ui.label(c, "Min (slow)", 9, Ui.MUTED, false);
        seekVal = Ui.label(c, Tools.touchText(seek.getProgress()), 10, Ui.lighten(Ui.SKY, 0.4f), true);
        seekVal.setGravity(Gravity.CENTER);
        TextView maxT = Ui.label(c, "Max (fast)", 9, Ui.MUTED, false);
        maxT.setGravity(Gravity.END);
        labels.addView(minT, new LinearLayout.LayoutParams(0, -2, 1f));
        labels.addView(seekVal, new LinearLayout.LayoutParams(0, -2, 1.2f));
        labels.addView(maxT, new LinearLayout.LayoutParams(0, -2, 1f));
        touch.addView(labels, new LinearLayout.LayoutParams(-1, -2));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                seekVal.setText(Tools.touchText(p));
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                final int p = sb.getProgress();
                runJob(null, () -> Tools.setTouch(getContext(), p));
            }
        });
        LinearLayout.LayoutParams tp = rowLp();
        list.addView(touch, tp);

        // ----- status -----
        list.addView(section("STATUS"));
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(d(12), d(10), d(12), d(10));
        box.setBackground(Ui.glass(c, Ui.NAVY, 14, 0x33FFFFFF, 1));
        stRam = statusRow(box, "How free is our RAM");
        stGame = statusRow(box, "Optimize game yet?");
        stSelf = statusRow(box, "Optimize AKULA GM yet?");
        stBg = statusRow(box, "Background clear?");
        stPower = statusRow(box, "Power saving mode?");
        stHeat = statusRow(box, "Heat reducer working?");
        list.addView(box, rowLp());

        LinearLayout shz = new LinearLayout(c);
        shz.setOrientation(LinearLayout.VERTICAL);
        shz.setPadding(d(12), d(10), d(12), d(10));
        shz.setBackground(Ui.glass(c, Ui.PURPLE, 14, Ui.alpha(Ui.PURPLE, 0x99), 1));
        shz.addView(Ui.label(c, "Shizuku status", 13, Ui.TXT, true));
        stShz = Ui.label(c, "", 11, Ui.TXT, true);
        LinearLayout.LayoutParams shp = new LinearLayout.LayoutParams(-2, -2);
        shp.topMargin = d(2);
        shz.addView(stShz, shp);
        LinearLayout btns = new LinearLayout(c);
        TextView refresh = Ui.pill(c, "Refresh", Ui.BLUE, Ui.TXT, 11);
        refresh.setOnClickListener(v -> {
            note.setText(Sh.state(getContext()) == 2 ? Sh.connect(getContext()) : "Checked Shizuku");
            update();
        });
        TextView go = Ui.pill(c, "Go to Shizuku?", Ui.PURPLE, Ui.TXT, 11);
        go.setOnClickListener(v -> note.setText(Sh.connect(getContext())));
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(0, -2, 1f);
        b1.rightMargin = d(4);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(0, -2, 1f);
        b2.leftMargin = d(4);
        btns.addView(refresh, b1);
        btns.addView(go, b2);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = d(8);
        shz.addView(btns, bp);
        list.addView(shz, rowLp());

        // ----- "Are you sure?" -----
        confirm = new FrameLayout(c);
        confirm.setBackgroundColor(0xCC000814);
        confirm.setClickable(true);
        confirm.setVisibility(GONE);
        LinearLayout cb = new LinearLayout(c);
        cb.setOrientation(LinearLayout.VERTICAL);
        cb.setGravity(Gravity.CENTER_HORIZONTAL);
        cb.setPadding(d(18), d(16), d(18), d(16));
        cb.setBackground(Ui.glass(c, 0xFFBFD7FF, 20, 0x66FFFFFF, 1.5f));
        TextView q = Ui.label(c, "Are you sure to close the window?", 15, Ui.TXT, true);
        q.setGravity(Gravity.CENTER);
        cb.addView(q);
        LinearLayout yn = new LinearLayout(c);
        TextView no = Ui.pill(c, "No", Ui.GREEN, Ui.GREEN, 15);
        no.setOnClickListener(v -> {
            confirm.setVisibility(GONE);
            host.collapse();
        });
        TextView yes = Ui.pill(c, "Yes", Ui.RED, Ui.RED, 15);
        yes.setOnClickListener(v -> host.quit());
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(0, -2, 1f);
        nl.rightMargin = d(8);
        LinearLayout.LayoutParams yl = new LinearLayout.LayoutParams(0, -2, 1f);
        yl.leftMargin = d(8);
        yn.addView(no, nl);
        yn.addView(yes, yl);
        LinearLayout.LayoutParams ynp = new LinearLayout.LayoutParams(-1, -2);
        ynp.topMargin = d(14);
        cb.addView(yn, ynp);
        FrameLayout.LayoutParams cbp = new FrameLayout.LayoutParams(d(280), -2, Gravity.CENTER);
        confirm.addView(cb, cbp);
        addView(confirm, new FrameLayout.LayoutParams(-1, -1));

        update();
    }

    // ----- builders -----
    private LinearLayout.LayoutParams statLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.leftMargin = d(4);
        p.rightMargin = d(4);
        return p;
    }

    private LinearLayout.LayoutParams rowLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = d(6);
        return p;
    }

    private TextView section(String s) {
        TextView t = Ui.label(getContext(), s, 10, Ui.MUTED, true);
        t.setLetterSpacing(0.15f);
        t.setPadding(d(2), d(12), 0, d(2));
        return t;
    }

    private TextView rf() {
        TextView t = Ui.pill(getContext(), "↻", Ui.BLUE, Ui.TXT, 16);
        t.setMinWidth(d(44));
        return t;
    }

    private TextView ab() {
        return Ui.pill(getContext(), "Activate", Ui.PURPLE, Ui.TXT, 11);
    }

    private Switch sw() {
        Switch s = new Switch(getContext());
        s.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{Ui.SKY, 0xFF94A3B8}));
        s.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{Ui.alpha(Ui.SKY, 0x77), 0x44FFFFFF}));
        return s;
    }

    private void addRow(LinearLayout list, String title, String sub, View control) {
        Context c = getContext();
        LinearLayout r = new LinearLayout(c);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(d(12), d(8), d(10), d(8));
        r.setBackground(Ui.glass(c, Ui.NAVY, 14, 0x33FFFFFF, 1));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(Ui.label(c, title, 13, Ui.TXT, true));
        col.addView(Ui.label(c, sub, 10, Ui.MUTED, false));
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(control, new LinearLayout.LayoutParams(-2, -2));
        list.addView(r, rowLp());
    }

    private TextView statusRow(LinearLayout box, String label) {
        Context c = getContext();
        LinearLayout r = new LinearLayout(c);
        r.setPadding(0, d(3), 0, d(3));
        TextView a = Ui.label(c, label, 11, Ui.MUTED, false);
        TextView b = Ui.label(c, "", 11, Ui.TXT, true);
        b.setGravity(Gravity.END);
        r.addView(a, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(b, new LinearLayout.LayoutParams(-2, -2));
        box.addView(r, new LinearLayout.LayoutParams(-1, -2));
        return b;
    }

    private void yn(TextView t, boolean yes) {
        t.setText(yes ? "Yes" : "No");
        t.setTextColor(yes ? Ui.GREEN : Ui.lighten(Ui.RED, 0.25f));
    }

    // ----- jobs -----
    private void runJob(final View lock, final Job job) {
        if (lock != null) {
            if (!lock.isEnabled()) return;
            lock.setEnabled(false);
            lock.setAlpha(0.5f);
        }
        note.setText("Working...");
        Tools.IO.execute(() -> {
            String m;
            try {
                m = job.run();
            } catch (Throwable e) {
                m = "Failed: " + e.getMessage();
            }
            final String msg = m;
            h.post(() -> {
                if (lock != null) {
                    lock.setEnabled(true);
                    lock.setAlpha(1f);
                }
                note.setText(msg);
                update();
            });
        });
    }

    // ----- live updates (only while the panel is open) -----
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            update();
            h.postDelayed(this, 1000);
        }
    };

    void start() {
        running = true;
        h.post(tick);
    }

    void stop() {
        running = false;
        h.removeCallbacksAndMessages(null);
    }

    private void applyFps(int f) {
        if (f < 0) {
            cFps.v.setText("N/A");
            cFps.s.setText(Sh.ready() ? "no game frames yet" : "needs Shizuku");
            cFps.setTint(Ui.GRAY);
            return;
        }
        cFps.v.setText(String.valueOf(f));
        cFps.s.setText("frames / sec");
        cFps.setTint(f < 15 ? Ui.RED : (f < 35 ? Ui.YELLOW : Ui.GREEN));
    }

    private void update() {
        Context c = getContext();
        long free = Tools.availMb(c), total = Tools.totalMb(c);
        cRam.v.setText(free + "/" + total);
        cRam.s.setText("MB free");

        float t = Tools.tempC(c);
        if (t < 0) {
            cTemp.v.setText("--");
            cTemp.s.setText("battery temp N/A");
        } else {
            cTemp.v.setText(String.format(Locale.US, "%.1f°C", t));
            cTemp.s.setText("battery temp");
            cTemp.setTint(t >= 40f ? Ui.ORANGE : Ui.SKY);
        }

        // FPS is measured every 2 seconds on a background thread (keeps the game smooth)
        if (tickN++ % 2 == 0 && busy.compareAndSet(false, true)) {
            final String pkg = Tools.target(c);
            Tools.IO.execute(() -> {
                int f = -1;
                try {
                    f = fps.sample(pkg);
                } catch (Throwable ignored) {
                }
                final int ff = f;
                busy.set(false);
                h.post(() -> applyFps(ff));
            });
        }

        boolean ps = Tools.powerSaveOn(c);
        syncing = true;
        if (swPower.isEnabled()) swPower.setChecked(ps);
        if (swPerf.isEnabled()) swPerf.setChecked(Tools.perf);
        if (swHeat.isEnabled()) swHeat.setChecked(Tools.heat);
        syncing = false;

        stRam.setText(free + " / " + total + " MB");
        yn(stGame, Tools.gameOpt);
        yn(stSelf, Tools.selfOpt);
        if (Tools.bg == 1) {
            stBg.setText("Yes");
            stBg.setTextColor(Ui.GREEN);
        } else if (Tools.bg == 2) {
            stBg.setText("Still have some");
            stBg.setTextColor(Ui.YELLOW);
        } else {
            stBg.setText("Not yet");
            stBg.setTextColor(Ui.lighten(Ui.RED, 0.25f));
        }
        yn(stPower, ps);
        yn(stHeat, Tools.heat);
        int s = Sh.state(c);
        stShz.setText(Sh.hint(s));
        stShz.setTextColor(s == 3 ? Ui.GREEN : Ui.lighten(Ui.ORANGE, 0.2f));
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        // A tap outside the panel folds it back into the circle
        if (e.getAction() == MotionEvent.ACTION_OUTSIDE) {
            host.collapse();
            return true;
        }
        return super.dispatchTouchEvent(e);
    }
}
