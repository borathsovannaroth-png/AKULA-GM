package com.akula.gm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** The AKULA logo (purple/black circle with a shark fin). Drawn in code, no image files. */
final class LogoView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path fin = new Path();
    private final Path wave = new Path();
    private Shader shader;

    LogoView(Context c) {
        super(c);
        fin.moveTo(30, 66);
        fin.quadTo(50, 60, 54, 26);
        fin.quadTo(64, 46, 76, 66);
        fin.close();
        wave.moveTo(24, 74);
        wave.quadTo(37, 66, 50, 74);
        wave.quadTo(63, 82, 76, 74);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float r = Math.min(w, h) / 2f;
        shader = new RadialGradient(w / 2f, h * 0.42f, r, 0xFF7C3AED, 0xFF0A0014, Shader.TileMode.CLAMP);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float r = Math.min(w, h) / 2f;
        float cx = w / 2f, cy = h / 2f;

        p.setStyle(Paint.Style.FILL);
        p.setShader(shader);
        cv.drawCircle(cx, cy, r, p);
        p.setShader(null);

        float ring = Ui.dp(getContext(), 2);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(ring);
        p.setColor(0xFFA78BFA);
        cv.drawCircle(cx, cy, r - ring / 2f, p);

        cv.save();
        cv.translate(cx - r, cy - r);
        float s = (2f * r) / 100f;
        cv.scale(s, s);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        cv.drawPath(fin, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0xFFC4B5FD);
        cv.drawPath(wave, p);
        cv.restore();
    }
}
