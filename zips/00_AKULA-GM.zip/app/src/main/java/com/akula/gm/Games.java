package com.akula.gm;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** The list of games inside the game space. Saved on the phone only. */
final class Games {
    private Games() {}

    static final class G {
        final String name;
        final String pkg;

        G(String name, String pkg) {
            this.name = name;
            this.pkg = pkg;
        }
    }

    static List<G> defaults() {
        List<G> l = new ArrayList<>();
        l.add(new G("Mobile Legends", "com.mobile.legends"));
        l.add(new G("Roblox", "com.roblox.client"));
        l.add(new G("Minecraft", "com.mojang.minecraftpe"));
        // Package name not known for sure: remove it and use "Add more game +" to pick the real one.
        l.add(new G("BB Racing", "com.bbracing.game"));
        l.add(new G("Subway Surf", "com.kiloo.subwaysurf"));
        return l;
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("akula", Context.MODE_PRIVATE);
    }

    static List<G> load(Context c) {
        String s = sp(c).getString("games", null);
        if (s == null) return defaults();
        List<G> l = new ArrayList<>();
        for (String line : s.split("\n")) {
            String[] p = line.split("\t");
            if (p.length == 2 && Sh.safePkg(p[1])) l.add(new G(p[0], p[1]));
        }
        return l;
    }

    static void save(Context c, List<G> l) {
        StringBuilder sb = new StringBuilder();
        for (G g : l) sb.append(g.name.replace('\t', ' ').replace('\n', ' ')).append('\t').append(g.pkg).append('\n');
        sp(c).edit().putString("games", sb.toString()).apply();
    }

    static PackageInfo info(PackageManager pm, String pkg) {
        try {
            return pm.getPackageInfo(pkg, 0);
        } catch (Throwable e) {
            return null;
        }
    }

    static Drawable icon(PackageManager pm, String pkg) {
        try {
            return pm.getApplicationIcon(pkg);
        } catch (Throwable e) {
            return null;
        }
    }

    static long apkBytes(PackageInfo pi) {
        try {
            ApplicationInfo a = pi.applicationInfo;
            long s = new File(a.sourceDir).length();
            if (a.splitSourceDirs != null) {
                for (String p : a.splitSourceDirs) s += new File(p).length();
            }
            return s;
        } catch (Throwable e) {
            return 0;
        }
    }
}
