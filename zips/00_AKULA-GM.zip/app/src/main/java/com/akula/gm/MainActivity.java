package com.akula.gm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private List<Games.G> games;
    private int sel = 0;

    private FrameLayout root, creditLayer;
    private LinearLayout content, listBox;
    private ImageView infoIcon;
    private TextView infoName, infoPkg, infoBody, infoStatus, launchBtn, shzText, connectBtn, banner;

    private final Shizuku.OnBinderReceivedListener binderL = this::refreshShizuku;
    private final Shizuku.OnBinderDeadListener deadL = this::refreshShizuku;
    private final Shizuku.OnRequestPermissionResultListener permL = (code, res) -> refreshShizuku();

    private int d(float v) {
        return Ui.dp(this, v);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        games = Games.load(this);
        buildUi();
        setContentView(root);
        hideBars();

        try {
            Shizuku.addBinderReceivedListenerSticky(binderL);
            Shizuku.addBinderDeadListener(deadL);
            Shizuku.addRequestPermissionResultListener(permL);
        } catch (Throwable ignored) {
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        refreshList();
        refreshInfo();
        refreshShizuku();
        h.postDelayed(() -> {
            if (!Sh.ready()) showBanner();
        }, 700);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshShizuku();
        refreshInfo();
    }

    @Override
    protected void onDestroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderL);
            Shizuku.removeBinderDeadListener(deadL);
            Shizuku.removeRequestPermissionResultListener(permL);
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onBackPressed() {
        if (creditLayer.getVisibility() == View.VISIBLE) {
            closeCredit();
        } else {
            moveTaskToBack(true);
        }
    }

    // ================= UI =================
    @SuppressWarnings("deprecation")
    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Ui.BG1, Ui.BG2}));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(d(12), d(8), d(12), d(8));
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int l = ins.getSystemWindowInsetLeft(), t = ins.getSystemWindowInsetTop();
            int r = ins.getSystemWindowInsetRight(), bt = ins.getSystemWindowInsetBottom();
            if (Build.VERSION.SDK_INT >= 28) {
                DisplayCutout dc = ins.getDisplayCutout();
                if (dc != null) {
                    l = Math.max(l, dc.getSafeInsetLeft());
                    t = Math.max(t, dc.getSafeInsetTop());
                    r = Math.max(r, dc.getSafeInsetRight());
                    bt = Math.max(bt, dc.getSafeInsetBottom());
                }
            }
            content.setPadding(d(12) + l, d(8) + t, d(12) + r, d(8) + bt);
            return ins;
        });

        // ----- top bar: credit icon + title -----
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView credit = Ui.label(this, "i", 16, Ui.TXT, true);
        credit.setGravity(Gravity.CENTER);
        GradientDrawable cb = new GradientDrawable();
        cb.setShape(GradientDrawable.OVAL);
        cb.setColor(Ui.NAVY);
        cb.setStroke(Math.max(1, d(1.5f)), Ui.BLUE);
        credit.setBackground(cb);
        credit.setClickable(true);
        credit.setOnClickListener(v -> openCredit());
        top.addView(credit, new LinearLayout.LayoutParams(d(34), d(34)));
        TextView title = Ui.label(this, "AKULA GM", 20, Ui.TXT, true);
        title.setShadowLayer(d(10), 0, 0, Ui.SKY);
        title.setLetterSpacing(0.06f);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.leftMargin = d(10);
        top.addView(title, tl);
        TextView sub = Ui.label(this, "Game Space", 11, Ui.MUTED, false);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
        sl.leftMargin = d(8);
        top.addView(sub, sl);
        content.addView(top, new LinearLayout.LayoutParams(-1, -2));

        // ----- middle: game list (left) + info (right) -----
        LinearLayout mid = new LinearLayout(this);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, 0, 1f);
        mp.topMargin = d(8);
        mp.bottomMargin = d(8);
        content.addView(mid, mp);

        ScrollView ls = new ScrollView(this);
        ls.setVerticalScrollBarEnabled(false);
        ls.setOverScrollMode(View.OVER_SCROLL_NEVER);
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        ls.addView(listBox, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams lsp = new LinearLayout.LayoutParams(0, -1, 4f);
        lsp.rightMargin = d(8);
        mid.addView(ls, lsp);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(d(14), d(12), d(14), d(12));
        info.setBackground(Ui.glass(this, 0xFFBFD7FF, 20, 0x55FFFFFF, 1.5f));
        mid.addView(info, new LinearLayout.LayoutParams(0, -1, 6f));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        infoIcon = new ImageView(this);
        infoIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        head.addView(infoIcon, new LinearLayout.LayoutParams(d(52), d(52)));
        LinearLayout hc = new LinearLayout(this);
        hc.setOrientation(LinearLayout.VERTICAL);
        infoName = Ui.label(this, "", 18, Ui.TXT, true);
        infoPkg = Ui.label(this, "", 11, Ui.lighten(Ui.SKY, 0.3f), false);
        infoPkg.setTypeface(android.graphics.Typeface.MONOSPACE);
        hc.addView(infoName);
        hc.addView(infoPkg);
        LinearLayout.LayoutParams hcp = new LinearLayout.LayoutParams(0, -2, 1f);
        hcp.leftMargin = d(10);
        head.addView(hc, hcp);
        info.addView(head, new LinearLayout.LayoutParams(-1, -2));

        ScrollView is = new ScrollView(this);
        is.setVerticalScrollBarEnabled(false);
        LinearLayout ib = new LinearLayout(this);
        ib.setOrientation(LinearLayout.VERTICAL);
        infoBody = Ui.label(this, "", 12, Ui.TXT, false);
        infoBody.setLineSpacing(d(2), 1f);
        infoStatus = Ui.label(this, "", 13, Ui.GREEN, true);
        ib.addView(infoBody);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-2, -2);
        stp.topMargin = d(6);
        ib.addView(infoStatus, stp);
        is.addView(ib, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams isp = new LinearLayout.LayoutParams(-1, 0, 1f);
        isp.topMargin = d(8);
        info.addView(is, isp);

        launchBtn = Ui.pill(this, "Launch it!", Ui.GREEN, Ui.TXT, 15);
        launchBtn.setPadding(d(22), d(9), d(22), d(9));
        launchBtn.setOnClickListener(v -> launch());
        LinearLayout.LayoutParams lbp = new LinearLayout.LayoutParams(-2, -2);
        lbp.gravity = Gravity.END;
        info.addView(launchBtn, lbp);

        // ----- bottom bar: Shizuku status -----
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(d(12), d(6), d(8), d(6));
        bar.setBackground(Ui.glass(this, Ui.NAVY, 16, 0x44FFFFFF, 1));
        shzText = Ui.label(this, "", 12, Ui.TXT, true);
        bar.addView(shzText, new LinearLayout.LayoutParams(0, -2, 1f));
        connectBtn = Ui.pill(this, "Connect now", Ui.PURPLE, Ui.TXT, 12);
        connectBtn.setOnClickListener(v -> {
            toast(Sh.connect(this));
            refreshShizuku();
        });
        bar.addView(connectBtn, new LinearLayout.LayoutParams(-2, -2));
        content.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        // ----- slide-down notice -----
        banner = Ui.label(this, "Shizuku is needed for some features. Tap to connect.", 12, Ui.TXT, true);
        banner.setGravity(Gravity.CENTER);
        banner.setPadding(d(16), d(9), d(16), d(9));
        banner.setBackground(Ui.glass(this, Ui.ORANGE, 18, Ui.alpha(Ui.ORANGE, 0xDD), 1.5f));
        banner.setVisibility(View.GONE);
        banner.setOnClickListener(v -> {
            hideBanner();
            toast(Sh.connect(this));
        });
        FrameLayout.LayoutParams bnp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        bnp.topMargin = d(6);
        root.addView(banner, bnp);

        // ----- credit popup (frost glass) -----
        creditLayer = new FrameLayout(this);
        creditLayer.setBackgroundColor(0x88000814);
        creditLayer.setClickable(true);
        creditLayer.setVisibility(View.GONE);
        creditLayer.setOnClickListener(v -> closeCredit());
        FrameLayout box = new FrameLayout(this);
        box.setClickable(true);
        box.setBackground(Ui.glass(this, 0xFFBFD7FF, 22, 0x77FFFFFF, 1.5f));
        LinearLayout bt = new LinearLayout(this);
        bt.setOrientation(LinearLayout.VERTICAL);
        bt.setPadding(d(22), d(18), d(22), d(20));
        bt.addView(Ui.label(this, "Credits", 18, Ui.TXT, true));
        TextView msg = Ui.label(this, "Thank you for checking our credit!\n\n"
                + "All of this is thanks to\nMe Borath Sovannroth and Gemini the GOAT.\n\n"
                + "No ads. No tracking. No payments.\nJust a smile.", 13, Ui.TXT, false);
        msg.setLineSpacing(d(2), 1f);
        LinearLayout.LayoutParams mgp = new LinearLayout.LayoutParams(-2, -2);
        mgp.topMargin = d(8);
        bt.addView(msg, mgp);
        box.addView(bt, new FrameLayout.LayoutParams(-1, -2));
        TextView cx = Ui.label(this, "X", 14, Ui.TXT, true);
        cx.setGravity(Gravity.CENTER);
        GradientDrawable xb = new GradientDrawable();
        xb.setShape(GradientDrawable.OVAL);
        xb.setColor(0x44FFFFFF);
        xb.setStroke(Math.max(1, d(1)), 0x99FFFFFF);
        cx.setBackground(xb);
        cx.setClickable(true);
        cx.setOnClickListener(v -> closeCredit());
        FrameLayout.LayoutParams cxp = new FrameLayout.LayoutParams(d(32), d(32), Gravity.TOP | Gravity.END);
        cxp.topMargin = d(10);
        cxp.rightMargin = d(10);
        box.addView(cx, cxp);
        creditLayer.addView(box, new FrameLayout.LayoutParams(d(340), -2, Gravity.CENTER));
        root.addView(creditLayer, new FrameLayout.LayoutParams(-1, -1));
    }

    private void openCredit() {
        creditLayer.setAlpha(0f);
        creditLayer.setVisibility(View.VISIBLE);
        creditLayer.animate().alpha(1f).setDuration(180).start();
        if (Build.VERSION.SDK_INT >= 31) {
            content.setRenderEffect(RenderEffect.createBlurEffect(16f, 16f, Shader.TileMode.CLAMP));
        }
    }

    private void closeCredit() {
        creditLayer.animate().alpha(0f).setDuration(150).withEndAction(() -> creditLayer.setVisibility(View.GONE)).start();
        if (Build.VERSION.SDK_INT >= 31) content.setRenderEffect(null);
    }

    private void showBanner() {
        banner.setTranslationY(-d(80));
        banner.setVisibility(View.VISIBLE);
        banner.animate().translationY(0).setDuration(300).start();
        h.postDelayed(this::hideBanner, 4500);
    }

    private void hideBanner() {
        banner.animate().translationY(-d(80)).setDuration(250)
                .withEndAction(() -> banner.setVisibility(View.GONE)).start();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ================= game list =================
    private void refreshList() {
        listBox.removeAllViews();
        PackageManager pm = getPackageManager();
        for (int i = 0; i < games.size(); i++) {
            final int idx = i;
            Games.G g = games.get(i);
            boolean on = i == sel;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(d(8), d(6), d(8), d(6));
            GradientDrawable bg = Ui.glass(this, on ? Ui.NAVY : 0xFF0A1A3A, 14, on ? Ui.RED : 0x22FFFFFF, on ? 2.5f : 1);
            row.setBackground(bg);
            ImageView ic = new ImageView(this);
            Drawable dr = Games.icon(pm, g.pkg);
            if (dr != null) {
                ic.setImageDrawable(dr);
            } else {
                GradientDrawable ph = new GradientDrawable();
                ph.setShape(GradientDrawable.OVAL);
                ph.setColor(Ui.alpha(Ui.PURPLE, 0x88));
                ic.setImageDrawable(ph);
            }
            row.addView(ic, new LinearLayout.LayoutParams(d(32), d(32)));
            TextView nm = Ui.label(this, (on ? "→ " : "") + g.name, 13, on ? Ui.TXT : Ui.MUTED, on);
            nm.setMaxLines(1);
            nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(0, -2, 1f);
            nl.leftMargin = d(8);
            row.addView(nm, nl);
            row.setOnClickListener(v -> {
                sel = idx;
                refreshList();
                refreshInfo();
            });
            row.setOnLongClickListener(v -> {
                confirmRemove(idx);
                return true;
            });
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.bottomMargin = d(6);
            listBox.addView(row, rp);
        }
        TextView add = Ui.label(this, "Add more game +", 13, Ui.lighten(Ui.SKY, 0.3f), true);
        add.setGravity(Gravity.CENTER);
        add.setPadding(d(8), d(10), d(8), d(10));
        add.setBackground(Ui.ripple(this, Ui.glass(this, 0xFF0A1A3A, 14, Ui.alpha(Ui.SKY, 0x66), 1), 14));
        add.setClickable(true);
        add.setOnClickListener(v -> addGame());
        listBox.addView(add, new LinearLayout.LayoutParams(-1, -2));
    }

    private void refreshInfo() {
        if (games.isEmpty()) {
            infoName.setText("No games yet");
            infoPkg.setText("");
            infoBody.setText("Tap \"Add more game +\" to pick a game you installed.");
            infoStatus.setText("");
            infoIcon.setImageDrawable(null);
            launchBtn.setAlpha(0.4f);
            return;
        }
        if (sel >= games.size()) sel = games.size() - 1;
        Games.G g = games.get(sel);
        PackageManager pm = getPackageManager();
        PackageInfo pi = Games.info(pm, g.pkg);
        infoName.setText(g.name);
        infoPkg.setText(g.pkg);
        Drawable dr = Games.icon(pm, g.pkg);
        infoIcon.setImageDrawable(dr);
        StringBuilder sb = new StringBuilder();
        sb.append("Data folder:\nAndroid/data/").append(g.pkg).append("\n\n");
        sb.append("OBB folder:\nAndroid/obb/").append(g.pkg).append("\n\n");
        if (pi != null) {
            long bytes = Games.apkBytes(pi);
            sb.append("Version: ").append(pi.versionName == null ? "?" : pi.versionName).append('\n');
            sb.append("App size: ").append(bytes > 0 ? String.format(Locale.US, "%.1f MB", bytes / 1048576.0) : "unknown").append('\n');
            sb.append("Updated: ").append(DateFormat.getDateFormat(this).format(new Date(pi.lastUpdateTime)));
            infoStatus.setText("Installed");
            infoStatus.setTextColor(Ui.GREEN);
            launchBtn.setAlpha(1f);
        } else {
            sb.append("This game is not installed on this phone.\nLong press it in the list to remove it.");
            infoStatus.setText("Not installed");
            infoStatus.setTextColor(Ui.lighten(Ui.RED, 0.25f));
            launchBtn.setAlpha(0.4f);
        }
        infoBody.setText(sb.toString());
    }

    private void refreshShizuku() {
        runOnUiThread(() -> {
            int s = Sh.state(this);
            shzText.setText("Shizuku status:  " + (s == 3 ? "Connected" : "Not yet"));
            shzText.setTextColor(s == 3 ? Ui.GREEN : Ui.lighten(Ui.ORANGE, 0.2f));
            connectBtn.setText(s == 3 ? "Connected" : "Connect now");
            connectBtn.setAlpha(s == 3 ? 0.5f : 1f);
        });
    }

    // ================= actions =================
    private void launch() {
        if (games.isEmpty()) {
            toast("Add a game first");
            return;
        }
        Games.G g = games.get(sel);
        Intent li = getPackageManager().getLaunchIntentForPackage(g.pkg);
        if (li == null) {
            toast(g.name + " is not installed");
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow \"Display over other apps\" for AKULA GM, then press Launch it! again");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            } catch (Throwable ignored) {
            }
            return;
        }
        try {
            startForegroundService(new Intent(this, OverlayService.class).putExtra("pkg", g.pkg).putExtra("name", g.name));
        } catch (Throwable e) {
            toast("Could not start the floating circle");
            return;
        }
        final String pkg = g.pkg;
        // quick boost before the game starts (frees RAM)
        Tools.IO.execute(() -> Tools.clearRam(getApplicationContext(), pkg));
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(li);
    }

    private void confirmRemove(final int idx) {
        final Games.G g = games.get(idx);
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Remove " + g.name + "?")
                .setMessage("It only leaves this list. The game stays on your phone.")
                .setPositiveButton("Remove", (dlg, w) -> {
                    games.remove(idx);
                    Games.save(this, games);
                    if (sel >= games.size()) sel = Math.max(0, games.size() - 1);
                    refreshList();
                    refreshInfo();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void addGame() {
        Tools.IO.execute(() -> {
            PackageManager pm = getPackageManager();
            List<ResolveInfo> l = pm.queryIntentActivities(
                    new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
            final Set<String> have = new HashSet<>();
            for (Games.G g : games) have.add(g.pkg);
            final List<Games.G> opts = new ArrayList<>();
            for (ResolveInfo r : l) {
                String p = r.activityInfo.packageName;
                if (p.equals(getPackageName()) || have.contains(p) || !Sh.safePkg(p)) continue;
                opts.add(new Games.G(String.valueOf(r.loadLabel(pm)), p));
            }
            Collections.sort(opts, (a, c) -> a.name.compareToIgnoreCase(c.name));
            final String[] labels = new String[opts.size()];
            for (int i = 0; i < labels.length; i++) labels[i] = opts.get(i).name;
            h.post(() -> {
                if (isFinishing()) return;
                if (labels.length == 0) {
                    toast("No more apps to add");
                    return;
                }
                new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                        .setTitle("Add a game")
                        .setItems(labels, (dlg, i) -> {
                            games.add(opts.get(i));
                            Games.save(this, games);
                            sel = games.size() - 1;
                            refreshList();
                            refreshInfo();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            });
        });
    }
}
