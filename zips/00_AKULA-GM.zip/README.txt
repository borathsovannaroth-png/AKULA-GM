AKULA GM - game space + floating overlay (native Android, Java)
No ads. No trackers. No INTERNET permission. No payments.

Build: upload everything to the ROOT of your GitHub repo, then run the
"Build AKULA GM APK" workflow (.github/workflows/build.yml).
APK = Actions > the run > Artifacts > AKULA-GM-apk
